// Pulse oximeter reading

var sensorData = parseInt(prompt("Please enter Oxygen Saturation sensor reading."));

function analyzeOximeterReading (sensorData) {
    if (sensorData > 95) {
        console.log("Normal reading.");
     } else if ((sensorData >= 92) && (sensorData < 95)) {
        console.log("Seek advice from health professionals.");
    } else if (sensorData < 92) {
        console.log("Seek urgent medical advice.");
    } else if (sensorData == 95) {
        console.log("Acceptable to continue home monitoring.");
    } else 
        console.log("I don't know what to say.")
}

analyzeOximeterReading(sensorData);


// Pulse oximeter reading part 2

var sensorData2 = parseInt(prompt("Please enter Pulse Rate per minute sensor reading."));

function analyzePulseRate (sensorData2) {
    if ((sensorData2 >= 40) && (sensorData2 <=100)) {
        console.log("Normal reading.");
     } else if  ((sensorData2 >= 101) && (sensorData2 <=109)) {
        console.log("Acceptable to continue home monitoring.");
    } else if ((sensorData2 >= 110) && (sensorData2 <=130)) {
        console.log("Seek advice from health professionals.");
    } else if (sensorData2 >= 131) {
        console.log("Seek urgent medical advice.");
    } else 
        console.log("Below 40, consult your doctor.")
}

analyzePulseRate(sensorData2);