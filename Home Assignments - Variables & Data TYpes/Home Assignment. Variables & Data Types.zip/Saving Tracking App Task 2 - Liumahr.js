//Determine Target Saving Amount
// Ask for current saved amount
// Display the percentage remaining to target saving amount from  saved amount

var nameUser = prompt("Hi, what is your name?");
// Ask for user's name.
var targetSavings = prompt("How much is your Goal of saving?");
//Assign goal saving amount  to variable
var savedAmount = prompt("How much did you save already?");
// Assign current save amount to variable

var percentRemaining = (targetSavings - savedAmount) / targetSavings * 100;
// Compute the remaining percentage of target amount from current saved amount
console.log(`"Thank you for your discipline and hardwork! As you already saved ${savedAmount} You are ${percentRemaining}% away from your goal of saving ${targetSavings}."`)
document.write("<br/>" + `"Thank you ${nameUser} for your discipline and hardwork! As you already saved ${savedAmount}, you are ${percentRemaining}% away from your goal of saving ${targetSavings}."`)
// Display the message