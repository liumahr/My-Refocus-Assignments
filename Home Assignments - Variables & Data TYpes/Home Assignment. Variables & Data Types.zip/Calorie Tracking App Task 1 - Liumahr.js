var nameUser = prompt("Please enter your name");
var calories = (225 / 30); //compute calories per minute
var time = prompt("How many minutes do you plan to cycle each day?");
//ask user to input how minutes he/she will work out a day
var day = prompt("How many days do you plan cycling?");
//ask user to input how many he/she plan to run
var burntCalories = Math.round(time * calories);
//compute calories per minute
var totalCaloriesburnt = burntCalories * day;
//compute how many calories burnt to number of days each week
console.log(`Great work, ${nameUser}, After cycling for ${time} minutes each day, you will lose ${totalCaloriesburnt} calories in ${day} day(s).`)
document.write("<br/>" + `Great work, ${nameUser}, After cycling for ${time} minutes each day, you will lose ${totalCaloriesburnt} calories in ${day} day(s).`)