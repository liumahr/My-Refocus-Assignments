//create a Function to convert Celsius to Kelvin and Farenheit to Kelvin.
//Formula for Celsius to Kelvin = C + 273.15
//Formula for Celsius to Farenheit = (F - 32) * 5/9 + 273.15

//code to convert Celsius degree to Kelvin.
function celsiusToKelvin() {
    var tempCelsius = parseInt(prompt ("Please enter Celsius degree to convert to Kelvin"));
    let tempKelvin_fromCelsius = tempCelsius + 273.15;
    return tempKelvin_fromCelsius;
}

console.log (celsiusToKelvin());


//Code to convert Farenheit degree to Kelvin
function farenheitToKelvin() {
    var tempFarenhiet = parseInt(prompt ("Please enter Farenheit degree to convert to Kelvin"));
    let tempKelvin_fromFarenheit = (tempFarenhiet - 32) * 5/9 + 273.15;
    return tempKelvin_fromFarenheit;
}

console.log (farenheitToKelvin())

//Tip Calculator - 10 % of the total bill amount.
function computeTip() {
    var totalBill = parseInt(prompt("Please enter the total bill amount to compute the tip"));
    let tipAmount = totalBill * 0.10;
    return tipAmount;

}

console.log(computeTip())

//code runs in browser console, will have error in VS code if run.